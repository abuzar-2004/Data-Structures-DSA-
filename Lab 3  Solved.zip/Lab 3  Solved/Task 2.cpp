//#include <iostream>
//using namespace std;
//
//template <typename Type>
//class Array {
//private:
//    Type* data; 
//    int size; 
//    int n; 
//
//    void grow()
//    {
//        size *= 2; 
//        Type* newData = new Type[size];
//        for (int i = 0; i < n; i++) 
//        {
//            newData[i] = data[i];
//        }
//        delete[] data; 
//        data = newData;
//    }
//
//    void shrink() 
//    {
//        size /= 2;
//        Type* newData = new Type[size];
//        for (int i = 0; i < n; i++) 
//        {
//            newData[i] = data[i];
//        }
//        delete[] data; 
//        data = newData;
//    }
//
//public:
//  
//    Array(int defaultSize = 10)
//    {
//        size = defaultSize;
//        n = 0;
//        data = new Type[size];
//    }
//
//  
//    Array(const Array<Type>& other)
//    {
//        size = other.size;
//        n = other.n;
//        data = new Type[size];
//        for (int i = 0; i < n; i++) 
//        {
//            data[i] = other.data[i];
//        }
//    }
//
//    
//    ~Array() 
//    {
//        delete[] data; 
//    }
//
//   
//    void add(Type element)
//    {
//        if (n == size)
//        {
//            grow();
//        }
//        data[n++] = element;
//    }
//
//    
//    void remove() 
//    {
//        if (n > 0) 
//        {
//            n--;
//            if (n < size / 2) 
//            {
//                shrink();
//            }
//        }
//        else
//        {
//            cout << "Array is empty, nothing to remove." << endl;
//        }
//    }
//
//   
//    int search(Type element)
//    {
//        for (int i = 0; i < n; i++)
//        {
//            if (data[i] == element) 
//            {
//                return i;
//            }
//        }
//        return -1;
//    }
//
//   
//    void sort()
//    {
//        for (int i = 0; i < n - 1; i++) 
//        {
//            for (int j = 0; j < n - i - 1; j++)
//            {
//                if (data[j] > data[j + 1])
//                {
//                    
//                    Type temp = data[j];
//                    data[j] = data[j + 1];
//                    data[j + 1] = temp;
//                }
//            }
//        }
//    }
//
//    
//    void print() {
//        for (int i = 0; i < n; i++)
//        {
//            cout << data[i] << " ";
//        }
//        cout << endl;
//    }
//};
//
//
//int main() 
//{
//    Array<int> intArray;
//    intArray.add(5);
//    intArray.add(2);
//    intArray.add(9);
//    intArray.add(1);
//    intArray.print();
//
//    intArray.sort();
//    intArray.print();
//
//    int index = intArray.search(9);
//    cout << "Index of 9: " << index << endl;
//
//    intArray.remove();
//    intArray.print();
//
//    return 0;
//}
