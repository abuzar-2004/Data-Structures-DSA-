//#include <iostream>
//using namespace std;
//
//template <typename T>
//
//int binarysearch(const T array[], int size, T key) 
//{
//    int left = 0, right = size - 1;
//
//    while (left <= right) 
//    {
//        int mid = left + (right - left) / 2; 
//
//        if (array[mid] == key) 
//        {
//            return mid; 
//        }
//        else if (array[mid] < key) 
//        {
//            left = mid + 1; 
//        }
//        else 
//        {
//            right = mid - 1; 
//        }
//    }
//
//    return -1;
//}
//
//
//template <typename T>
//void searchresult(int index, T key) 
//{
//    if (index != -1)
//    {
//        cout << "Key " << key << " found at index " << index << "." << endl;
//    }
//    else
//    {
//        cout << "Key " << key << " not found in the array." << endl;
//    }
//}
//
//int main()
//{
// 
//    int intArray[5] = { 11, 12, 22, 25, 64 };
//    int intKey = 22;
//    int intIndex = binarysearch(intArray, 5, intKey);
//    searchresult(intIndex, intKey);
//
//    
//    float floatArray[4] = { 0.57, 1.62, 2.71, 3.14 };
//    float floatKey = 2.71;
//    int floatIndex = binarysearch(floatArray, 4, floatKey);
//    searchresult(floatIndex, floatKey);
//
//    
//    string stringArray[4] = { "apple", "banana", "grape", "orange" };
//    string stringKey = "banana";
//    int stringIndex = binarysearch(stringArray, 4, stringKey);
//    searchresult(stringIndex, stringKey);
//
//    return 0;
//}
