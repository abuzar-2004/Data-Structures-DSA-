//#include <iostream>
//#include <string>
//using namespace std;
//
//class Student
//{
//public:
//    int id;
//    string name;
//    float CGPA;
//
//    friend istream& operator>>(istream& input, Student& s)
//    {
//        cout << "Enter ID: ";
//        input >> s.id;
//        cout << "Enter Name: ";
//        input.ignore(); 
//        getline(input, s.name);
//        cout << "Enter CGPA: ";
//        input >> s.CGPA;
//        return input;
//    }
//
//    friend ostream& operator<<(ostream& output, const Student& s) 
//    {
//        output << "ID: " << s.id << " | Name: " << s.name << " | CGPA: " << s.CGPA;
//        return output;
//    }
//
//
//    bool operator<(const Student& other) const 
//    {
//        return CGPA < other.CGPA; 
//    }
//
//    bool operator==(const Student& other) const 
//    {
//        return id == other.id; 
//    }
//};
//
//template <typename Type>
//class Array 
//{
//private:
//    Type* data; 
//    int size; 
//    int n; 
//
//    void grow() 
//    {
//        size *= 2; 
//        Type* newData = new Type[size];
//        for (int i = 0; i < n; i++) {
//            newData[i] = data[i];
//        }
//        delete[] data; 
//        data = newData;
//        cout << "Array size doubled to " << size << endl;
//    }
//
//    void shrink() 
//    {
//        size /= 2; 
//        Type* newData = new Type[size];
//        for (int i = 0; i < n; i++) 
//        {
//            newData[i] = data[i];
//        }
//        delete[] data; 
//        data = newData;
//        cout << "Array size reduced to " << size << endl;
//    }
//
//public:
//    
//    Array(int defaultSize = 3) 
//    {
//        size = defaultSize;
//        n = 0;
//        data = new Type[size];
//        cout << "Initial array created with size " << size << endl;
//    }
//
//    ~Array() 
//    {
//        delete[] data; 
//    }
//
//    void add(Type element)
//    {
//        if (n == size) 
//        {
//            cout << "Array full. Growing array..." << endl;
//            grow();
//        }
//        data[n++] = element;
//    }
//
//    void remove()
//    {
//        if (n > 0)
//        {
//            n--;
//            cout << "Student removed." << endl;
//            if (n < size / 2)
//            {
//                cout << "Shrinking array..." << endl;
//                shrink();
//            }
//        }
//        else 
//        {
//            cout << "Array is empty, nothing to remove." << endl;
//        }
//    }
//
//    int search(Type element)
//    {
//        for (int i = 0; i < n; i++)
//        {
//            if (data[i] == element)
//            {
//                return i; 
//            }
//        }
//        return -1; 
//    }
//
//    void sort() {
//        for (int i = 0; i < n - 1; i++) 
//        {
//            for (int j = 0; j < n - i - 1; j++) 
//            {
//                if (data[j] < data[j + 1]) 
//                {
//                    Type temp = data[j];
//                    data[j] = data[j + 1];
//                    data[j + 1] = temp;
//                }
//            }
//        }
//        cout << "Sorting completed." << endl;
//    }
//
//    void print() {
//        for (int i = 0; i < n; i++) {
//            cout << i + 1 << ". " << data[i] << endl;
//        }
//    }
//};
//
//int main() 
//{
// 
//    Array<Student> studentArray;
//
//
//    cout << "Adding 4 students to array..." << endl;
//    for (int i = 0; i < 4; i++) 
//    {
//        Student s;
//        cin >> s;
//        studentArray.add(s);
//        cout << "Student added: " << s << endl;
//    }
//
//
//    cout << "---Current Student Records---" << endl;
//    studentArray.print();
//
//   
//    cout << "Enter ID to search: ";
//    int searchID;
//    cin >> searchID;
//    Student searchStudent;
//    searchStudent.id = searchID; 
//    int index = studentArray.search(searchStudent);
//    if (index != -1) {
//        cout << "Student found at index: " << index << endl;
//    }
//    else 
//    {
//        cout << "Student not found." << endl;
//    }
//
//    studentArray.remove();
//
//
//    cout << "Sorting students by CGPA..." << endl;
//    studentArray.sort();
//
//    cout << "---Sorted Student Records---" << endl;
//    studentArray.print();
//
//    return 0;
//}
