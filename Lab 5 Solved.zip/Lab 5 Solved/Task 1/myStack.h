# pragma once

#include "AbstractStack.h"
#include <iostream>
using namespace std;

template<typename T>
class myStack : public AbstractStack<T> 
{
private:
    T* stackArray;
    int maxSize;
    int topIndex;

public:
    myStack(int size) : maxSize(size), topIndex(-1) 
    {
        stackArray = new T[maxSize];
    }

    ~myStack() 
    {
        delete[] stackArray;
    }

    void push(T value) override 
    {
        if (isFull()) {
            cout << "Stack is full. Cannot push." << endl;
        }
        else 
        {
            stackArray[topIndex++] = value;
        }
    }

    T pop() override 
    {
        if (isEmpty()) 
        {
            cout << "Stack is empty. Cannot pop." << endl;
            return T(); 
        }
        else 
        {
            return stackArray[topIndex--];
        }
    }

    T top() const override 
    {
        if (isEmpty())
        {
            cout << "Stack is empty. No top element." << endl;
            return T(); 
        }
        else {
            return stackArray[topIndex];
        }
    }

    bool isEmpty() const override 
    {
        return topIndex == -1;
    }

    bool isFull() const override
    {
        return topIndex == maxSize - 1;
    }

    void display() 
    {
        if (isEmpty()) 
        {
            cout << "Stack is empty." << endl;
        }
        else
        {
            cout << "Stack elements: ";
            for (int i = 0; i <= topIndex; i++)
            {
                cout << stackArray[i] << " ";
            }
            cout << endl;
        }
    }
};


