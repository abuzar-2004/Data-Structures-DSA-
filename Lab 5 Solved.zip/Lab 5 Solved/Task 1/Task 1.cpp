#include "myStack.h"
#include <iostream>
using namespace std;

int main() 
{
    int size;
    cout << "Enter the size of the stack: ";
    cin >> size;

    myStack<int> stack(size);

    int choice;
    do 
    {
        cout << "\nStack Operations Menu:\n";
        cout << "1. Push\n";
        cout << "2. Pop\n";
        cout << "3. Top\n";
        cout << "4. Check if Empty\n";
        cout << "5. Check if Full\n";
        cout << "6. Display\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: 
        {
            int value;
            cout << "Enter value to push: ";
            cin >> value;
            stack.push(value);
            break;
        }
        case 2:
            cout << "Popped value: " << stack.pop() << endl;
            break;
        case 3:
            cout << "Top element: " << stack.top() << endl;
            break;
        case 4:
            cout << (stack.isEmpty() ? "Stack is empty." : "Stack is not empty.") << endl;
            break;
        case 5:
            cout << (stack.isFull() ? "Stack is full." : "Stack is not full.") << endl;
            break;
        case 6:
            stack.display();
            break;
        case 7:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } 
    while (choice != 7);

    return 0;
}
