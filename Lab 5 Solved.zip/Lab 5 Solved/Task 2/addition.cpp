#include "addition.h"
#include <string>
using namespace std;

const int MAX_SIZE = 10000; 

string performAddition(const string& num1, const string& num2)
{
    int stack1[MAX_SIZE], stack2[MAX_SIZE], resultStack[MAX_SIZE];
    int top1 = -1, top2 = -1, topResult = -1;


    for (char digit : num1) 
    {
        stack1[++top1] = digit - '0'; 
    }

    
    for (char digit : num2)
    {
        stack2[++top2] = digit - '0'; 
    }

    int carry = 0;
    while (top1 >= 0 || top2 >= 0 || carry != 0)
    {
        int digit1 = (top1 >= 0) ? stack1[top1--] : 0; 
        int digit2 = (top2 >= 0) ? stack2[top2--] : 0; 

        int sum = digit1 + digit2 + carry;
        resultStack[++topResult] = sum % 10; 
        carry = sum / 10;                    
    }

    string result;
    while (topResult >= 0) 
    {
        result += to_string(resultStack[topResult--]); 
    }

    return result;
}
