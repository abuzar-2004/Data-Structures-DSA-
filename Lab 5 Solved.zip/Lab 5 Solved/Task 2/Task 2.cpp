#include <iostream>
#include "addition.h"

using namespace std;

int main() 
{
    string num1, num2;

    cout << "Enter the first large number: ";
    cin >> num1;
    cout << "Enter the second large number: ";
    cin >> num2;

    string result = performAddition(num1, num2);
    cout << "The sum is: " << result << endl;

    return 0;
}
