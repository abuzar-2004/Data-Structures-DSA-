#pragma once

class Stack
{
private:
    static const int MAX_SIZE = 100;
    char stack[MAX_SIZE];
    int top;

public:
    Stack();
    void push(char c);
    char pop();
    bool isEmpty() const;
};


