#include <iostream>
#include "Stack.h"

using namespace std;

bool isPalindrome(const string& input) 
{
    Stack stack;
    for (char c : input) 
    {
        stack.push(c);
    }
    string reversed;
    while (!stack.isEmpty())
    {
        reversed += stack.pop();
    }
    return input == reversed;
}

int main() 
{
    string input;
    cout << "Enter a string: ";
    cin >> input;
    if (isPalindrome(input))
    {
        cout << "\"" << input << "\" is a palindrome.\n";
    }
    else 
    {
        cout << "\"" << input << "\" is not a palindrome.\n";
    }
    return 0;
}
