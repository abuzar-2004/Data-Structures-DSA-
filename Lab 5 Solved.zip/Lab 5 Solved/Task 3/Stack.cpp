#include "Stack.h"
#include <iostream>

using namespace std;

Stack::Stack() : top(-1) {}

void Stack::push(char c)
{
    if (top >= MAX_SIZE - 1) 
    {
        cerr << "Stack overflow";
        exit(EXIT_FAILURE);
    }
    stack[++top] = c;
}

char Stack::pop() 
{
    if (top < 0) 
    {
        cerr << "Stack is empty";
        exit(EXIT_FAILURE);
    }
    return stack[top--];
}

bool Stack::isEmpty() const
{
    return top == -1;
}
