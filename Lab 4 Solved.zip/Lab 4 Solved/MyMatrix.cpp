//#include "MyMatrix.h"
//
//
//template <typename Type>
//MyMatrix<Type>::MyMatrix(int r, int c) : rows(r), cols(c), matrix(r, std::vector<Type>(c, Type())) {}
//
//template <typename Type>
//MyMatrix<Type>::MyMatrix(const MyMatrix<Type>& other) : rows(other.rows), cols(other.cols), matrix(other.matrix), lastValue(other.lastValue) {}
//
//template <typename Type>
//MyMatrix<Type>::~MyMatrix() {}
//
//template <typename Type>
//bool MyMatrix<Type>::isEmpty() const {
//    for (const auto& row : matrix) {
//        for (const auto& value : row) {
//            if (value != Type()) return false;  
//        }
//    }
//    return true;  
//}
//
//template <typename Type>
//bool MyMatrix<Type>::isFull() const {
//    for (const auto& row : matrix) {
//        for (const auto& value : row) {
//            if (value == Type()) return false;  
//        }
//    }
//    return true;  
//}
//
//template <typename Type>
//int MyMatrix<Type>::getRowSize() const {
//    return rows;
//}
//
//
//template <typename Type>
//int MyMatrix<Type>::getColSize() const {
//    return cols;
//}
//
//
//template <typename Type>
//bool MyMatrix<Type>::updateValue(int row, int col, Type value) {
//    if (row >= 0 && row < rows && col >= 0 && col < cols) {
//        matrix[row][col] = value;
//        lastValue = value;
//        return true;
//    }
//    return false;  
//}
//
//template <typename Type>
//Type MyMatrix<Type>::getLastValue() const {
//    return lastValue;
//}
//
//
//template <typename Type>
//bool MyMatrix<Type>::search(Type value) const {
//    for (const auto& row : matrix) {
//        for (const auto& val : row) {
//            if (val == value) return true;
//        }
//    }
//    return false;
//}
//
//template <typename Type>
//void MyMatrix<Type>::displayMatrix() const {
//    for (const auto& row : matrix) {
//        for (const auto& value : row) {
//            std::cout << value << " ";
//        }
//        std::cout << std::endl;
//    }
//}
//
//
//template class MyMatrix<int>;
//template class MyMatrix<float>;
//template class MyMatrix<double>;
//template class MyMatrix<std::string>;
