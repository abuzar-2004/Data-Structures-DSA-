//#include "Matrix.h"
//#include <iostream>
//using namespace std;
//
//int main() {
//    Matrix<int> mat(3, 3);
//
//    mat.insertValue(0, 0, 5);
//    mat.insertValue(1, 1, 10);
//    mat.insertValue(2, 2, 15);
//
//    cout << "Matrix after insertion:" << endl;
//    mat.displayMatrix();
//
//    cout << "\nValue at (1, 1): " << mat.getValue(1, 1) << endl;
//
//    mat.deleteValue(1, 1);
//    cout << "\nMatrix after deleting value at (1, 1):" << endl;
//    mat.displayMatrix();
//
//    cout << "\nSearching for value 10: " << (mat.searchValue(10) ? "Found" : "Not Found") << endl;
//    cout << "Searching for value 5: " << (mat.searchValue(5) ? "Found" : "Not Found") << endl;
//
//    return 0;
//}
