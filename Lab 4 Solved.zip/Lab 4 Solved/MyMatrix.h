//#pragma once 
//
//#include <iostream>
//#include <vector>
//
//using namespace std;
//
//template <typename Type>
//class MyMatrix 
//{
//private:
//    int rows;
//    int cols;
//    vector<vector<Type>> matrix;
//    Type lastValue;
//
//public:
//    
//    MyMatrix(int r = 3, int c = 3);
//
//  
//    MyMatrix(const MyMatrix<Type>& other);
//
//  
//    ~MyMatrix();
//
//    
//    bool isEmpty() const;
//
// 
//    bool isFull() const;
//
//    int getRowSize() const;
//
//
//    int getColSize() const;
//
//    bool updateValue(int row, int col, Type value);
//
//
//    Type getLastValue() const;
//
//  
//    bool search(Type value) const;
//
//
//    void displayMatrix() const;
//};
//
//
