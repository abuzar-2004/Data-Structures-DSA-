//#include "Matrix.h"
//#include <iostream>
//using namespace std;
//
//template <typename Type>
//Matrix<Type>::Matrix(int r, int c) : rows(r), cols(c)
//{
//    arr = new Type * [rows];
//    for (int i = 0; i < rows; ++i)
//    {
//        arr[i] = new Type[cols]{};
//    }
//}
//
//template <typename Type>
//Matrix<Type>::Matrix(const Matrix& other) : rows(other.rows), cols(other.cols) 
//{
//    arr = new Type * [rows];
//    for (int i = 0; i < rows; ++i) 
//    {
//        arr[i] = new Type[cols];
//        for (int j = 0; j < cols; ++j) 
//        {
//            arr[i][j] = other.arr[i][j];
//        }
//    }
//}
//
//template <typename Type>
//Matrix<Type>::~Matrix() 
//{
//    for (int i = 0; i < rows; ++i) 
//    {
//        delete[] arr[i];
//    }
//    delete[] arr;
//}
//
//template <typename Type>
//bool Matrix<Type>::insertValue(int row, int col, Type value)
//{
//    if (row < 0 || row >= rows || col < 0 || col >= cols) 
//    {
//        std::cout << "Error: Invalid indices (" << row << ", " << col << ")\n";
//        return false;
//    }
//    arr[row][col] = value;
//    return true;
//}
//
//template <typename Type>
//Type Matrix<Type>::getValue(int row, int col)
//{
//    if (row < 0 || row >= rows || col < 0 || col >= cols) 
//    {
//        std::cout << "Error: Invalid indices (" << row << ", " << col << ")\n";
//        return Type();
//    }
//    return arr[row][col];
//}
//
//template <typename Type>
//void Matrix<Type>::displayMatrix() 
//{
//    for (int i = 0; i < rows; ++i)
//    {
//        for (int j = 0; j < cols; ++j)
//        {
//            cout << arr[i][j] << "\t";
//        }
//        cout << endl;
//    }
//}
//
//template <typename Type>
//bool Matrix<Type>::deleteValue(int row, int col)
//{
//    if (row < 0 || row >= rows || col < 0 || col >= cols)
//    {
//        cout << "Error: Invalid indices (" << row << ", " << col << ")\n";
//        return false;
//    }
//    arr[row][col] = Type();
//    return true;
//}
//
//template <typename Type>
//bool Matrix<Type>::searchValue(Type value)
//{
//    for (int i = 0; i < rows; ++i)
//    {
//        for (int j = 0; j < cols; ++j)
//        {
//            if (arr[i][j] == value)
//            {
//                return true;
//            }
//        }
//    }
//    return false;
//}
//
//
//template class Matrix<int>;
//template class Matrix<float>;
//template class Matrix<double>;
