//#include <iostream>
//#include "MyMatrix.h"
//
//template <typename Type>
//void displayMenu() {
//    cout << "Menu Options:\n";
//    cout << "1. Check if matrix is empty\n";
//    cout << "2. Check if matrix is full\n";
//    cout << "3. Get matrix row size\n";
//    cout << "4. Get matrix column size\n";
//    cout << "5. Update matrix value\n";
//    cout << "6. Get last value entered\n";
//    cout << "7. Search for value in matrix\n";
//    cout << "8. Display matrix\n";
//    cout << "9. Exit\n";
//}
//
//template <typename Type>
//void menu(MyMatrix<Type>& matrix) {
//    int choice;
//    Type value;
//    int row, col;
//
//    while (true) {
//        displayMenu<Type>();
//        std::cout << "Enter choice: ";
//        std::cin >> choice;
//
//        switch (choice) {
//        case 1:
//            std::cout << "Matrix is " << (matrix.isEmpty() ? "empty" : "not empty") << ".\n";
//            break;
//        case 2:
//            std::cout << "Matrix is " << (matrix.isFull() ? "full" : "not full") << ".\n";
//            break;
//        case 3:
//            std::cout << "Matrix row size: " << matrix.getRowSize() << "\n";
//            break;
//        case 4:
//            std::cout << "Matrix column size: " << matrix.getColSize() << "\n";
//            break;
//        case 5:
//            std::cout << "Enter row, column, and value to update: ";
//            std::cin >> row >> col >> value;
//            if (matrix.updateValue(row, col, value)) {
//                std::cout << "Value updated successfully.\n";
//            }
//            else {
//                std::cout << "Failed to update value. Invalid index.\n";
//            }
//            break;
//        case 6:
//            std::cout << "Last value entered: " << matrix.getLastValue() << "\n";
//            break;
//        case 7:
//            std::cout << "Enter value to search for: ";
//            std::cin >> value;
//            if (matrix.search(value)) {
//                std::cout << "Value found in matrix.\n";
//            }
//            else {
//                std::cout << "Value not found in matrix.\n";
//            }
//            break;
//        case 8:
//            matrix.displayMatrix();
//            break;
//        case 9:
//            std::cout << "Exiting program...\n";
//            return;
//        default:
//            std::cout << "Invalid choice, try again.\n";
//        }
//    }
//}
//
//int main() 
//{
//    MyMatrix<int> matrix(3, 3); 
//
//    menu(matrix);
//
//    return 0;
//}
