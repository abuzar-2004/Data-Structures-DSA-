//#include "MyList.h"
//
//template <typename Type>
//MyList<Type>::MyList(int maxSize) {
//    this->maxSize = maxSize;
//    this->currentSize = 0;
//    this->arr = new Type[maxSize];
//}
//
//template <typename Type>
//MyList<Type>::MyList(const MyList<Type>& other) {
//    maxSize = other.maxSize;
//    currentSize = other.currentSize;
//    arr = new Type[maxSize];
//    for (int i = 0; i < currentSize; ++i) {
//        arr[i] = other.arr[i];
//    }
//}
//
//template <typename Type>
//MyList<Type>::~MyList() {
//    delete[] arr;
//}
//
//template <typename Type>
//bool MyList<Type>::empty() const {
//    return currentSize == 0;
//}
//
//template <typename Type>
//bool MyList<Type>::full() const {
//    return currentSize == maxSize;
//}
//
//template <typename Type>
//int MyList<Type>::size() const {
//    return currentSize;
//}
//
//template <typename Type>
//bool MyList<Type>::insertAt(int index, Type value) {
//    if (index >= 0 && index <= currentSize && currentSize < maxSize) {
//        for (int i = currentSize; i > index; --i) {
//            arr[i] = arr[i - 1];
//        }
//        arr[index] = value;
//        currentSize++;
//        return true;
//    }
//    return false;
//}
//
//template <typename Type>
//Type MyList<Type>::last() const {
//    if (currentSize > 0) {
//        return arr[currentSize - 1];
//    }
//    throw runtime_error("List is empty");
//}
//
//template <typename Type>
//bool MyList<Type>::search(Type value) const {
//    for (int i = 0; i < currentSize; ++i) {
//        if (arr[i] == value) {
//            return true;
//        }
//    }
//    return false;
//}
//
//template <typename Type>
//void MyList<Type>::display() const {
//    cout << "List: ";
//    for (int i = 0; i < currentSize; ++i) {
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//}
