//#include <iostream>
//#include "MyList.h"
//using namespace std;
//
//int main() 
//{
//    MyList<int> myList(10); 
//    int choice, index, value;
//
//    do {
//        cout << "\nMenu:\n";
//        cout << "1. Insert element at a specific index\n";
//        cout << "2. Check if the list is empty\n";
//        cout << "3. Check if the list is full\n";
//        cout << "4. Get the current size of the list\n";
//        cout << "5. Get the last element of the list\n";
//        cout << "6. Search for an element in the list\n";
//        cout << "7. Display the list\n";
//        cout << "8. Exit\n";
//        cout << "Enter your choice: ";
//        cin >> choice;
//
//        switch (choice) {
//        case 1:
//            cout << "Enter the index to insert at: ";
//            cin >> index;
//            cout << "Enter the value to insert: ";
//            cin >> value;
//            if (myList.insertAt(index, value)) {
//                cout << "Element inserted successfully." << endl;
//            }
//            else {
//                cout << "Failed to insert. Index might be out of bounds or list is full." << endl;
//            }
//            break;
//
//        case 2:
//            cout << (myList.empty() ? "The list is empty." : "The list is not empty.") << endl;
//            break;
//
//        case 3:
//            cout << (myList.full() ? "The list is full." : "The list is not full.") << endl;
//            break;
//
//        case 4:
//            cout << "Current size of the list: " << myList.size() << endl;
//            break;
//
//        case 5:
//            try {
//                cout << "Last element in the list: " << myList.last() << endl;
//            }
//            catch (runtime_error& e) {
//                cout << "Error: " << e.what() << endl;
//            }
//            break;
//
//        case 6:
//            cout << "Enter the value to search for: ";
//            cin >> value;
//            cout << (myList.search(value) ? "Element found in the list." : "Element not found in the list.") << endl;
//            break;
//
//        case 7:
//            myList.display();
//            break;
//
//        case 8:
//            cout << "Exiting the program. Goodbye!" << endl;
//            break;
//
//        default:
//            cout << "Invalid choice. Please try again." << endl;
//        }
//    } while (choice != 8);
//
//    return 0;
//}
