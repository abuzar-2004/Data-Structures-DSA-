//#pragma once
//
//#include <iostream>
//using namespace std;
//
//template <typename Type>
//class MyList {
//private:
//    Type* arr;
//    int maxSize;
//    int currentSize;
//
//public:
//    MyList(int maxSize = 10); 
//    MyList(const MyList& other); 
//    ~MyList();
//
//    bool empty() const;
//    bool full() const; 
//    int size() const; 
//    bool insertAt(int index, Type value); 
//    Type last() const; 
//    bool search(Type value) const; 
//    void display() const; 
//};
//
