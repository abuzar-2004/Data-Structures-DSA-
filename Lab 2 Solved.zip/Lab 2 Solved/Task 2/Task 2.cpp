//#include<iostream>
//using namespace std;
//
//template <typename T>
//void avg(T arr[], int size)
//{
//    T sum = 0;
//    for (int i = 0; i < size; i++)
//    {
//        sum = sum +arr[i];
//    }
//    T average = sum / size;
//    cout << "The average is: " << average << endl;
//}
//
//int main()
//{
//    int arr[5] = { 1, 2, 3, 4, 5 };
//    avg<int>(arr, 5);
//
//    return 0;
//}
