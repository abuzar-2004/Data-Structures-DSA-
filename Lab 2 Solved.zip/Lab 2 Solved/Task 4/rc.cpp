//#include "rc.h"
//#include <iostream>
//using namespace std;
//
//rc::rc() {
//    name = "";
//    score = 0;
//}
//
//rc::rc(string n, double s) {
//    name = n;
//    score = s;
//}
//
//void rc::display() {
//    cout << "Name: " << name << ", Score: " << score << endl;
//}
//
//double rc::getScore() {
//    return score;
//}
//
//string rc::getName() {
//    return name;
//}
