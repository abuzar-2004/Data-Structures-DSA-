//# pragma once
//
//#include <string>
//using namespace std;
//
//class rc {
//private:
//    string name;
//    double score;
//public:
//    rc();
//    rc(string n, double s);
//    void display();
//    double getScore();
//    string getName();
//};
//
//
