//#include <iostream>
//#include <string>
//#include "rc.h"
//using namespace std;
//
//int main() {
//    int a;
//    cout << "Enter the number of students: " << endl;
//    cin >> a;
//
//    cin.ignore();
//
//    rc* p = new rc[a];
//
//    string name;
//    double sc;
//
//    double highestScore = -1, lowestScore = 101;
//    string highestName, lowestName;
//
//    for (int i = 0; i < a; i++) {
//        cout << "Enter name of student " << i + 1 << ": ";
//        getline(cin, name);
//
//        cout << "Enter score of student " << i + 1 << ": ";
//        cin >> sc;
//        cin.ignore();
//
//        p[i] = rc(name, sc);
//
//        if (sc > highestScore) {
//            highestScore = sc;
//            highestName = name;
//        }
//
//        if (sc < lowestScore) {
//            lowestScore = sc;
//            lowestName = name;
//        }
//    }
//
//    for (int i = 0; i < a; i++) {
//        p[i].display();
//    }
//
//    cout << "\nStudent with highest score: " << highestName << " with score " << highestScore << endl;
//    cout << "Student with lowest score: " << lowestName << " with score " << lowestScore << endl;
//
//    delete[] p;
//    return 0;
//}
