//#include <iostream>
//#include "List.h"
//using namespace std;
//
//template <typename Type>
//class MyList : public List<Type> {
//public:
//    MyList(int maxSize = 10) : List<Type>(maxSize) {}
//
//    void addElementAtFirstIndex(Type value) override {
//        if (this->currentSize < this->maxSize) {
//            for (int i = this->currentSize; i > 0; --i) {
//                this->arr[i] = this->arr[i - 1];
//            }
//            this->arr[0] = value;
//            this->currentSize++;
//        }
//        else {
//            cout << "List is full!" << endl;
//        }
//    }
//
//    void addElementAtLastIndex(Type value) override {
//        if (this->currentSize < this->maxSize) {
//            this->arr[this->currentSize++] = value;
//        }
//        else {
//            cout << "List is full!" << endl;
//        }
//    }
//
//    Type removeElementFromEnd() override {
//        if (this->currentSize > 0) {
//            return this->arr[--this->currentSize];
//        }
//        else {
//            cout << "List is empty!" << endl;
//            return Type();
//        }
//    }
//
//    void removeElementFromStart() override {
//        if (this->currentSize > 0) {
//            for (int i = 0; i < this->currentSize - 1; ++i) {
//                this->arr[i] = this->arr[i + 1];
//            }
//            this->currentSize--;
//        }
//        else {
//            cout << "List is empty!" << endl;
//        }
//    }
//
//    void display() {
//        cout << "List: ";
//        for (int i = 0; i < this->currentSize; ++i) {
//            cout << this->arr[i] << " ";
//        }
//        cout << endl;
//    }
//};
//
//int main() {
//    MyList<int> list(5);
//
//    list.addElementAtFirstIndex(10);
//    list.addElementAtFirstIndex(20);
//    list.addElementAtLastIndex(30);
//    list.display();
//
//    list.removeElementFromStart();
//    list.display();
//
//    list.removeElementFromEnd();
//    list.display();
//
//    return 0;
//}
