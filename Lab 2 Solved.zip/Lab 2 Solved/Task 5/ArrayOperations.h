//#ifndef ARRAYOPERATIONS_H
//#define ARRAYOPERATIONS_H
//
//#include <iostream>
//using namespace std;
//
//template <typename T>
//class ArrayOperations {
//private:
//    T* arr;
//    int size;
//
//public:
//    ArrayOperations(int size);
//    ~ArrayOperations();
//    void setElement(int index, T value);
//    T getElement(int index);
//    T findMin();
//    T findMax();
//    void reverseArray();
//    void inputElements();
//    void displayArray();
//};
//
//#include "ArrayOperations.cpp"
//#endif
