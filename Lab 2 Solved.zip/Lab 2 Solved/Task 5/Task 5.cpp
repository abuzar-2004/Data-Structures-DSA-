//#include <iostream>
//#include "ArrayOperations.h"
//using namespace std;
//
//int main() {
//    int size;
//    cout << "Enter the size of the array: ";
//    cin >> size;
//
//    ArrayOperations<int> arrayOps(size);
//    arrayOps.inputElements();
//
//    cout << "Minimum value: " << arrayOps.findMin() << endl;
//    cout << "Maximum value: " << arrayOps.findMax() << endl;
//
//    int index, value;
//    cout << "Enter index to set a value: ";
//    cin >> index;
//    cout << "Enter value to set at index " << index << ": ";
//    cin >> value;
//    arrayOps.setElement(index, value);
//    cout << "Element at index " << index << " is now: " << arrayOps.getElement(index) << endl;
//
//    arrayOps.reverseArray();
//    cout << "Reversed array: ";
//    arrayOps.displayArray();
//
//    return 0;
//}
