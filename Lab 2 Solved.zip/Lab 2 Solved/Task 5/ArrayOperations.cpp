//#include "ArrayOperations.h"
//
//template <typename T>
//ArrayOperations<T>::ArrayOperations(int size) {
//    this->size = size;
//    arr = new T[size];
//}
//
//template <typename T>
//ArrayOperations<T>::~ArrayOperations() {
//    delete[] arr;
//}
//
//template <typename T>
//void ArrayOperations<T>::setElement(int index, T value) {
//    if (index >= 0 && index < size) {
//        arr[index] = value;
//    }
//}
//
//template <typename T>
//T ArrayOperations<T>::getElement(int index) {
//    if (index >= 0 && index < size) {
//        return arr[index];
//    }
//    return T();
//}
//
//template <typename T>
//T ArrayOperations<T>::findMin() {
//    T minVal = arr[0];
//    for (int i = 1; i < size; i++) {
//        if (arr[i] < minVal) {
//            minVal = arr[i];
//        }
//    }
//    return minVal;
//}
//
//template <typename T>
//T ArrayOperations<T>::findMax() {
//    T maxVal = arr[0];
//    for (int i = 1; i < size; i++) {
//        if (arr[i] > maxVal) {
//            maxVal = arr[i];
//        }
//    }
//    return maxVal;
//}
//
//template <typename T>
//void ArrayOperations<T>::reverseArray() {
//    int left = 0;
//    int right = size - 1;
//    while (left < right) {
//        T temp = arr[left];
//        arr[left] = arr[right];
//        arr[right] = temp;
//        left++;
//        right--;
//    }
//}
//
//template <typename T>
//void ArrayOperations<T>::inputElements() {
//    cout << "Enter the elements of the array:\n";
//    for (int i = 0; i < size; ++i) {
//        cin >> arr[i];
//    }
//}
//
//template <typename T>
//void ArrayOperations<T>::displayArray() {
//    cout << "Array: ";
//    for (int i = 0; i < size; i++) {
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//}
