//#pragma once
//template<typename T>
//class Storage
//{
//    {
//    private:
//        T value;
//
//    public:
//        Storage(T newval);
//        void setvalue(T val);
//        T getvalue();
//    };
//
//};
//
//
//
