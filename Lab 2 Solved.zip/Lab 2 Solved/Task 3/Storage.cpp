//#include "Storage.h"
//#include<string>
//
//template<typename T>
//Storage<T>::Storage(T newval) {
//    value = newval;
//}
//
//template<typename T>
//void Storage<T>::setvalue(T val) {
//    value = val;
//}
//
//template<typename T>
//T Storage<T>::getvalue() {
//    return value;
//}
//
//
//template class Storage<int>;
//
