//#include"Storage.h"
//#include<iostream>
//using namespace std;
//int main()
//{
//
//	Storage<int>p(5);
//	cout << "The value before set : " << p.getvalue() << endl;
//	p.setvalue(20);
//	cout << "The value After set : " << p.getvalue() << endl;
//
//
//
//	return 0;
//}