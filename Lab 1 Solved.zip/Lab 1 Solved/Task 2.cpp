//#include<iostream>
//#include<string>
//using namespace std;
//
//int main()
//{
//	float num1;
//	float num2;
//	float* nam1 = &num1;
//	float* nam2 = &num2;
//
//	cout << "enter the number 1 : ";
//	cin >> *nam1;
//	cout << "enter the number 2 : ";
//	cin >> *nam2;
//
//	char operation;
//	char* operate = &operation;
//
//	cout << "enter the operation (+,-,/,*) : ";
//	cin >> *operate;
//
//	float result;
//	float* resu = &result;
//
//	if (*operate == '+')
//	{
//		*resu = *nam1 + *nam2;
//	}
//	else if (*operate == '-')
//	{
//		*resu = *nam1 - *nam2;
//	}
//	else if (*operate == '/')
//	{
//		*resu = *nam1 / *nam2;
//	}
//	else if (*operate == '*')
//	{
//		*resu = *nam1 * *nam2;
//	}
//
//	else
//	{
//		cout << "invalid opeation !";
//		
//	}
//
//	cout << "Result:" << *resu << endl;
//
//	return 0;
//}