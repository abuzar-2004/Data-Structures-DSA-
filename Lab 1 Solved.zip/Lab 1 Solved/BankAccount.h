//#ifndef BANK_ACCOUNT_H
//#define BANK_ACCOUNT_H
//
//#include <string>
//
//class BankAccount {
//protected:
//    std::string title;
//    std::string accountNumber;
//    double balance;
//    std::string dateOfOpening;
//
//public:
//    static int totalAccounts;
//
//    BankAccount(const std::string& t, const std::string& accNum, double bal, const std::string& date);
//    virtual ~BankAccount();
//
//    virtual void deposit(double amount);
//    virtual void withdraw(double amount);
//    double getBalance() const;
//};
//
//class SavingsAccount : public BankAccount {
//private:
//    double interestRate;
//
//public:
//    static int totalSavingsAccounts;
//
//    SavingsAccount(const std::string& t, const std::string& accNum, double bal, const std::string& date, double rate);
//    ~SavingsAccount() override;
//
//    void calculateInterest();
//    void deposit(double amount) override;
//    void withdraw(double amount) override;
//};
//
//class CheckingAccount : public BankAccount {
//private:
//    double fee;
//
//public:
//    static int totalCheckingAccounts;
//
//    CheckingAccount(const std::string& t, const std::string& accNum, double bal, const std::string& date, double transactionFee);
//    ~CheckingAccount() override;
//
//    void deposit(double amount) override;
//    void withdraw(double amount) override;
//};
//
//#endif
