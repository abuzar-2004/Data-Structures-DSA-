//#include "CarbonFootprint.h"
//
//using namespace std;
//
//int main() 
//{
//    
//    Electricity electricity(500); 
//    NaturalGas naturalGas(400); 
//    Vehicle vehicle(250, 25);
//
//    
//    CarbonFootprint* footprints[3];
//    footprints[0] = &electricity;
//    footprints[1] = &naturalGas;
//    footprints[2] = &vehicle;
//
//    
//    for (int i = 0; i < 3; i++) 
//    {
//        display(footprints[i]);
//    }
//
//    return 0;
//}
