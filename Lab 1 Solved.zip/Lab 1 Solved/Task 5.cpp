//#include "BankAccount.h"
//#include <iostream>
//
//using namespace std;
//
//int main() {
//    SavingsAccount savings("John Doe", "S123", 1000, "01-01-2022", 5);
//    CheckingAccount checking("Jane Doe", "C456", 500, "01-02-2022", 10);
//
//    savings.deposit(200);
//    checking.deposit(100);
//
//    savings.withdraw(150);
//    checking.withdraw(50);
//
//    cout << "Savings Account Balance: " << savings.getBalance() << endl;
//    cout << "Checking Account Balance: " << checking.getBalance() << endl;
//
//    cout << "Total Savings Accounts: " << SavingsAccount::totalSavingsAccounts << endl;
//    cout << "Total Checking Accounts: " << CheckingAccount::totalCheckingAccounts << endl;
//
//    return 0;
//}
