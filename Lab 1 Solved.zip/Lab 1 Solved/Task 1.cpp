//#include<iostream>
//using namespace std;
//
//int main()
//{
//	int price;
//	int* ptr = &price;
//
//	cout << "enter the price of car : ";
//	cin >> *ptr;
//
//	float install;
//	install = *ptr * 0.12 + 15000;
//
//	cout << "1st installment is: " << install << endl;
//	
//	return 0;
//}