//
//class Rectangle {
//private:
//    double length;
//    double width;
//
//    
//    bool isValid(double value);
//
//public:
//   
//    Rectangle(double l = 1.0, double w = 1.0);
//
//    
//    void setLength(double l);
//
//    
//    double getLength() const;
//
//  
//    void setWidth(double w);
//
//   
//    double getWidth() const;
//
//   
//    double perimeter() const;
//
//    
//    double area() const;
//};