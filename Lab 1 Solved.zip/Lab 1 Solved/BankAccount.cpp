//#include "BankAccount.h"
//#include <iostream>
//
//using namespace std;
//
//int BankAccount::totalAccounts = 0;
//int SavingsAccount::totalSavingsAccounts = 0;
//int CheckingAccount::totalCheckingAccounts = 0;
//
//// BankAccount Implementation
//BankAccount::BankAccount(const std::string& t, const std::string& accNum, double bal, const std::string& date)
//    : title(t), accountNumber(accNum), balance(bal), dateOfOpening(date) {
//    totalAccounts++;
//}
//
//BankAccount::~BankAccount() {
//    totalAccounts--;
//}
//
//void BankAccount::deposit(double amount) {
//    balance += amount;
//}
//
//void BankAccount::withdraw(double amount) {
//    if (amount <= balance) {
//        balance -= amount;
//    }
//    else {
//        cout << "Insufficient balance." << endl;
//    }
//}
//
//double BankAccount::getBalance() const {
//    return balance;
//}
//
//// SavingsAccount Implementation
//SavingsAccount::SavingsAccount(const std::string& t, const std::string& accNum, double bal, const std::string& date, double rate)
//    : BankAccount(t, accNum, bal, date), interestRate(rate) {
//    totalSavingsAccounts++;
//}
//
//SavingsAccount::~SavingsAccount() {
//    totalSavingsAccounts--;
//}
//
//void SavingsAccount::calculateInterest() {
//    double interest = balance * (interestRate / 100);
//    balance += interest;
//}
//
//void SavingsAccount::deposit(double amount) {
//    double interest = amount * (interestRate / 100);
//    balance += (amount + interest);
//}
//
//void SavingsAccount::withdraw(double amount) {
//    if (amount <= balance) {
//        double interest = amount * (interestRate / 100);
//        balance -= (amount + interest);
//    }
//    else {
//        cout << "Insufficient balance." << endl;
//    }
//}
//
//// CheckingAccount Implementation
//CheckingAccount::CheckingAccount(const std::string& t, const std::string& accNum, double bal, const std::string& date, double transactionFee)
//    : BankAccount(t, accNum, bal, date), fee(transactionFee) {
//    totalCheckingAccounts++;
//}
//
//CheckingAccount::~CheckingAccount() {
//    totalCheckingAccounts--;
//}
//
//void CheckingAccount::deposit(double amount) {
//    balance += amount - fee;
//}
//
//void CheckingAccount::withdraw(double amount) {
//    if ((amount + fee) <= balance) {
//        balance -= (amount + fee);
//    }
//    else {
//        cout << "Insufficient balance." << endl;
//    }
//}
