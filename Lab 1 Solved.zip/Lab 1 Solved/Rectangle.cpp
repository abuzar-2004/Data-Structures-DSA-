//#include "Rectangle.h"
//#include <iostream>
//
//
//Rectangle::Rectangle(double l, double w) {
//    setLength(l);
//    setWidth(w);
//}
//
//bool Rectangle::isValid(double value) {
//    return (value > 0.0 && value < 20.0);
//}
//
//
//void Rectangle::setLength(double l) {
//    if (isValid(l)) {
//        length = l;
//    }
//    else {
//        std::cout << "Error: Length must be a floating-point number between 0.0 and 20.0. Using default value (1.0)." << std::endl;
//        length = 1.0; 
//    }
//}
//
//double Rectangle::getLength() const {
//    return length;
//}
//
//void Rectangle::setWidth(double w) {
//    if (isValid(w)) {
//        width = w;
//    }
//    else {
//        std::cout << "Error: Width must be a floating-point number between 0.0 and 20.0. Using default value (1.0)." << std::endl;
//        width = 1.0; 
//    }
//}
//
//double Rectangle::getWidth() const {
//    return width;
//}
//
//double Rectangle::perimeter() const {
//    return 2 * (length + width);
//}
//
//
//double Rectangle::area() const {
//    return length * width;
//}