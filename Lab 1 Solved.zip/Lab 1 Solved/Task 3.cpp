//#include <iostream>
//#include <fstream>
//
//using namespace std;
//
//// Function to search for the key in the array
//int* searchKey(int* arr, int size, int key) {
//    int* nearestGreater = nullptr;
//
//    for (int i = 0; i < size; i++) {
//        if (arr[i] == key) {
//            return &arr[i]; // Return the address of the element if the key is found
//        }
//        if (arr[i] > key) {
//            if (!nearestGreater || arr[i] < *nearestGreater) {
//                nearestGreater = &arr[i]; // Update nearest greater if it's closer
//            }
//        }
//    }
//    return nearestGreater; // Return nearest greater if the key is not found
//}
//
//int main() {
//    ifstream file("data.txt");
//    if (!file) {
//        cerr << "Error opening file!" << endl;
//        return 1;
//    }
//
//    int size;
//    file >> size; // Read the size of the array
//
//    // Dynamically allocate memory for the array
//    int* arr = new int[size];
//
//    // Read the elements of the array from the file
//    for (int i = 0; i < size; i++) {
//        file >> arr[i];
//    }
//
//    int key;
//    file >> key; // Read the key
//
//    // Call the function to search for the key
//    int* result = searchKey(arr, size, key);
//
//    if (result) {
//        cout << "Result found at address: " << result << endl;
//        cout << "Value at address: " << *result << endl;
//    }
//    else {
//        cout << "No greater element found." << endl;
//    }
//
//    // Deallocate the memory
//    delete[] arr;
//
//    return 0;
//}
