//#include "Rectangle.h"
//#include <iostream>
//
//int main() 
//{
//    Rectangle rect; 
//    std::cout << "Default Length: " << rect.getLength() << ", Default Width: " << rect.getWidth() << std::endl;
//    std::cout << "Perimeter: " << rect.perimeter() << std::endl;
//    std::cout << "Area: " << rect.area() << std::endl;
//
//    
//    rect.setLength(5.5);
//    rect.setWidth(10.2);
//    std::cout << "Updated Length: " << rect.getLength() << ", Updated Width: " << rect.getWidth() << std::endl;
//    std::cout << "Perimeter: " << rect.perimeter() << std::endl;
//    std::cout << "Area: " << rect.area() << std::endl;
//
//    
//    rect.setLength(25.0); 
//    rect.setWidth(-3.0); 
//    std::cout << "After Invalid Input - Length: " << rect.getLength() << ", Width: " << rect.getWidth() << std::endl;
//    std::cout << "Perimeter: " << rect.perimeter() << std::endl;
//    std::cout << "Area: " << rect.area() << std::endl;
//
//    return 0;
//}